package edu.uic.medicationreminder;

import android.content.SharedPreferences;
import android.content.SharedPreferences.OnSharedPreferenceChangeListener;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.speech.RecognizerIntent;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import android.content.Intent;
import android.support.v4.app.FragmentTransaction;
import android.net.Uri;

import opennlp.tools.postag.POSModel;
import opennlp.tools.tokenize.SimpleTokenizer;
import opennlp.tools.tokenize.Tokenizer;
import opennlp.tools.tokenize.TokenizerME;
import opennlp.tools.tokenize.TokenizerModel;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements ReminderListFragment.ReminderListFragmentListener,
        ReminderDetailFragment.ReminderDetailFragmentListener,
        ReminderAddEditFragment.ReminderAddEditFragmentListener,
        ReminderListVoiceFragment.ReminderListVoiceFragmentListener{

    // key for storing a contact's Uri in a Bundle passed to a fragment
    public static final String MEDICATION_REMINDER_URI = "medication_reminder_uri";

    private ReminderListFragment reminderListFragment; // displays medication reminder list
    private ReminderDetailFragment reminderDetailFragment;

    // keys for reading data from SharedPreferences
    public static final String CHOICES = "pref_uiChoices";
    private boolean phoneDevice = true; // used to force portrait mode
    private boolean preferencesChanged = true;
    private String userPref;
    private Tokenizer nlpTokenizer;
    private Intent srIntent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Set up the User Preferences
        PreferenceManager.setDefaultValues(this, R.xml.preferences, false);
        PreferenceManager.getDefaultSharedPreferences(this).registerOnSharedPreferenceChangeListener(preferencesChangeListener);

        // Check to see what the user's preferences are
        SharedPreferences sharedPref = PreferenceManager.getDefaultSharedPreferences(this);
        sharedPref.registerOnSharedPreferenceChangeListener(preferencesChangeListener);
        userPref = sharedPref.getString("pref_uiChoices", "");

        // if user preference is voice, load up the OpenNLP tokenizer model and the speech recognizer
        if (userPref.equalsIgnoreCase("VOICE")) {
            AssetManager am = getAssets();
            try {
                InputStream inputStream = am.open("en-token.bin");
                TokenizerModel model = new TokenizerModel(inputStream);
                nlpTokenizer = new TokenizerME(model);


            } catch (FileNotFoundException ex) {
                ex.printStackTrace();
            }
            catch(IOException ioe) {
                ioe.printStackTrace();
            }

            //get the recognize intent
            srIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            //Specify the calling package to identify your application
            srIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE,getClass().getPackage().getName());
            //Given an hint to the recognizer about what the user is going to say
            srIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            //specify the max number of results
            srIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1);
        }

        // Display the Touch ReminderList by default
        if (savedInstanceState == null && findViewById(R.id.fragmentContainer) != null) {
            if (userPref.equalsIgnoreCase("VOICE")) {
                ReminderListVoiceFragment reminderListVoiceFragment = new ReminderListVoiceFragment();

                // add the fragment to the FrameLayout
                FragmentTransaction transaction =
                        getSupportFragmentManager().beginTransaction();
                transaction.add(R.id.fragmentContainer, reminderListVoiceFragment);
                transaction.commit();
            }
            else {
                reminderListFragment = new ReminderListFragment();

                // add the fragment to the FrameLayout
                FragmentTransaction transaction =
                        getSupportFragmentManager().beginTransaction();
                transaction.add(R.id.fragmentContainer, reminderListFragment);
                transaction.commit();
            }
        }

    }

    public Tokenizer getOpenNlpTokenizer() {
        return nlpTokenizer;
    }

    public Intent getSpeechRecognizerIntent() {
        return srIntent;
    }

    // called after onCreate completes execution
    @Override
    protected void onStart() {
        super.onStart();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    // displays the SettingsActivity when running on a phone
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent preferencesIntent = new Intent(this, UserPreferencesActivity.class);
        startActivity(preferencesIntent);
        return super.onOptionsItemSelected(item);
    }

    private OnSharedPreferenceChangeListener preferencesChangeListener =
            new OnSharedPreferenceChangeListener() {
                // called when the user changes the app's preferences
                @Override
                public void onSharedPreferenceChanged(
                        SharedPreferences sharedPreferences, String key) {
                    preferencesChanged = true; // user changed app setting
                    userPref = sharedPreferences.getString("pref_uiChoices", "");
                    Toast.makeText(MainActivity.this,
                            "Preferences changed to " + userPref + ". Please restart the app for them to take effect.",
                            Toast.LENGTH_SHORT).show();

                }
            };

    // action to show the ReminderDetailFragment for selected reminder
    @Override
    public void onReminderSelected(Uri medicationReminderUri) {
        if (findViewById(R.id.fragmentContainer) != null)
            showReminder(medicationReminderUri, R.id.fragmentContainer);
    }

    // action to show the ReminderAddEditFragment to add a new reminder
    @Override
    public void onAddReminder() {
        if (findViewById(R.id.fragmentContainer) != null)
            showReminderAddEditFragment(R.id.fragmentContainer, null);
    }

    // show the Reminder Detail

    private void showReminder(Uri medicationReminderUri, int viewID) {
        ReminderDetailFragment reminderDetailFragment = new ReminderDetailFragment();

        Bundle arguments = new Bundle();
        arguments.putParcelable(MEDICATION_REMINDER_URI, medicationReminderUri);
        reminderDetailFragment.setArguments(arguments);

        // show the screen
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(viewID, reminderDetailFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    // show the Reminder add/edit form

    private void showReminderAddEditFragment(int viewID, Uri medicationReminderUri) {
        ReminderAddEditFragment reminderAddEditFragment = new ReminderAddEditFragment();

        // if editing existing medication reminder, provide Uri as an argument
        if (medicationReminderUri != null) {
            Bundle arguments = new Bundle();
            arguments.putParcelable(MEDICATION_REMINDER_URI, medicationReminderUri);
            reminderAddEditFragment.setArguments(arguments);
        }

        // show the screen
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(viewID, reminderAddEditFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    // show the Reminder List for Touch preference
    private void showReminderListFragment(int viewID, Uri medicationReminderUri) {

        ReminderListFragment reminderListFragment = new ReminderListFragment();

        // if editing existing medication reminder, provide Uri as an argument
        if (medicationReminderUri != null) {
            Bundle arguments = new Bundle();
            arguments.putParcelable(MEDICATION_REMINDER_URI, medicationReminderUri);
            reminderListFragment.setArguments(arguments);
        }

        // show the screen
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(viewID, reminderListFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    // show the Reminder List for Touch preference
    private void showReminderListVoiceFragment(int viewID, Uri medicationReminderUri) {

        ReminderListVoiceFragment reminderListVoiceFragment = new ReminderListVoiceFragment();

        // if editing existing medication reminder, provide Uri as an argument
        if (medicationReminderUri != null) {
            Bundle arguments = new Bundle();
            arguments.putParcelable(MEDICATION_REMINDER_URI, medicationReminderUri);
            reminderListVoiceFragment.setArguments(arguments);
        }

        // show the screen
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(viewID, reminderListVoiceFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }


    @Override
    public void onReminderDeleted() {
        // removes top of back stack
        getSupportFragmentManager().popBackStack();
        reminderListFragment.updateReminderList();
    }

    @Override
    public void onEditReminder(Uri medicationReminderUri) {
        if (findViewById(R.id.fragmentContainer) != null) // phone
            showReminderAddEditFragment(R.id.fragmentContainer, medicationReminderUri);

    }

    @Override
    public void onAddEditCompleted(Uri medicationReminderUri) {
        // removes top of back stack
        getSupportFragmentManager().popBackStack();
        reminderListFragment.updateReminderList();

        if (findViewById(R.id.fragmentContainer) == null) { // tablet
            // removes top of back stack
            getSupportFragmentManager().popBackStack();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        Fragment fragmentType = getSupportFragmentManager().findFragmentById(R.id.fragmentContainer);

        if (fragmentType != null) {
            fragmentType.onActivityResult(requestCode, resultCode, data);
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
