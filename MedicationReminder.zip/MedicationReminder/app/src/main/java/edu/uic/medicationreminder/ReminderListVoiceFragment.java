package edu.uic.medicationreminder;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Locale;

import edu.uic.medicationreminder.db.MedicationReminderDatabaseDescription;

import static android.app.Activity.RESULT_OK;

public class ReminderListVoiceFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {

    // callback method implemented by MainActivity
    public interface ReminderListVoiceFragmentListener {
        // called when a reminder is selected
        void onReminderSelected(Uri medicationReminderUri);

        // called when add button is pressed
        void onAddReminder();

    }

    private static final int MEDICATION_REMINDER_LOADER = 0;

    private ReminderListVoiceFragment.ReminderListVoiceFragmentListener listener;

    private ReminderListVoiceAdapter reminderListVoiceAdapter; // adapter for recyclerView

    private ImageButton speakButton;
    private TextToSpeech tts;
    private SpeechRecognizer sr;

    private static final int REQUEST_CODE = 1;
    private static final String TAG = "speechrec";

    // configures this fragment's GUI
    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        setHasOptionsMenu(true);


        final View view = inflater.inflate(R.layout.fragment_reminder_voice_list, container, false);
        speakButton = (ImageButton) view.findViewById(R.id.speak_button);
        speakButton.setOnClickListener(speakButtonListener);
        RecyclerView recyclerView =
                (RecyclerView) view.findViewById(R.id.recyclerViewVoice);
        recyclerView.setLayoutManager(
                new LinearLayoutManager(getActivity().getBaseContext()));

        reminderListVoiceAdapter = new ReminderListVoiceAdapter(
                new ReminderListVoiceAdapter.ReminderListVoiceClickListener() {
                    @Override
                    public void onClick(Uri medicationReminderUri) {
                        listener.onReminderSelected(medicationReminderUri);
                    }
                }
        );
        recyclerView.setAdapter(reminderListVoiceAdapter); // set the adapter

        // attach a custom ItemDecorator to draw dividers between list items
        recyclerView.addItemDecoration(new ItemDivider(getContext()));

        // improves performance if RecyclerView's layout size never changes
        recyclerView.setHasFixedSize(true);

        tts = new TextToSpeech(getContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int code) {
                if (code == TextToSpeech.SUCCESS) {
                    tts.setLanguage(Locale.US);
                }
                //Greeting message
                String greeting = "Here are your medication reminders for today.  Please tap on the microphone to speak";
                convertTTS(greeting);
                TextView text = (TextView) view.findViewById(R.id.speak_text);
                text.setText(greeting);
            }
        });
        //get the SpeechRecognizer and set a listener for it.
        sr = SpeechRecognizer.createSpeechRecognizer(getActivity());
        sr.setRecognitionListener(new SpeechListener());
        return view;
    }

    private void convertTTS(String text) {
        if (text.length() > 0) {
            tts.speak(text, TextToSpeech.QUEUE_FLUSH, null);

        }
    }

    /*
  * The Recognitionlistener for the SpeechRecognizer.
  */
    class SpeechListener implements RecognitionListener {
        public void onReadyForSpeech(Bundle params) {

        }

        public void onBeginningOfSpeech() {

        }

        public void onRmsChanged(float rmsdB) {

        }

        public void onBufferReceived(byte[] buffer) {

        }

        public void onEndOfSpeech() {
            ;
        }

        public void onError(int error) {
            Log.d(TAG, "error " + error);
            tts.speak("I'm sorry I did not get your response.  Would you please repeat it for me?", TextToSpeech.QUEUE_FLUSH, null);

        }

        public void onResults(Bundle results) {

            Log.d(TAG, "onResults " + results);
            // Fill the list view with the strings the recognizer thought it could have heard
            ArrayList<String> matches = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
            //display results.
            for (int i = 0; i < matches.size(); i++) {
                Log.d(TAG, "result " + matches.get(i));
            }
            // tokenize the user speech
            if (results != null) {
                String tokens[] = ((MainActivity) getActivity()).getOpenNlpTokenizer().tokenize((String) matches.get(0));
                for (String a : tokens) {
                    System.out.print("[" + a + "] ");
                }
            } else {
                tts.speak("I'm sorry I did not get your response.  Would you please repeat it for me?", TextToSpeech.QUEUE_FLUSH, null);
            }

        }

        public void onPartialResults(Bundle partialResults) {
            Log.d(TAG, "onPartialResults");
        }

        public void onEvent(int eventType, Bundle params) {
            Log.d(TAG, "onEvent " + eventType);
        }
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        listener = (ReminderListVoiceFragment.ReminderListVoiceFragmentListener) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;

    }

    private View.OnClickListener speakButtonListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            //listener.onEditReminder(medicationReminderUri);
            startVoiceRecognitionActivity();

        }
    };

    /**
     * Fire an intent to start the voice recognition activity.
     */
    private void startVoiceRecognitionActivity() {
        Intent srIntent = ((MainActivity) getActivity()).getSpeechRecognizerIntent();
        sr.startListening(srIntent);
        Log.i(TAG, "Intent sent");
    }

    @Override
    public void onDestroy() {

        sr.destroy();
        sr = null;
        if (tts != null) {
            tts.stop();
            tts.shutdown();
        }
        super.onDestroy();
    }

    // initialize a Loader when this fragment's activity is created
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getLoaderManager().initLoader(MEDICATION_REMINDER_LOADER, null, this);
    }

    // called from MainActivity when other Fragment's update database
    public void updateReminderList() {
        reminderListVoiceAdapter.notifyDataSetChanged();
    }

    // called by LoaderManager to create a Loader
    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        // create an appropriate CursorLoader based on the id argument;
        // only one Loader in this fragment, so the switch is unnecessary
        switch (id) {
            case MEDICATION_REMINDER_LOADER:
                return new CursorLoader(getActivity(),
                        MedicationReminderDatabaseDescription.MedicationReminder.CONTENT_URI, // Uri of medication_reminder table
                        null, // null projection returns all columns
                        null, // null selection returns all rows
                        null, // no selection arguments
                        MedicationReminderDatabaseDescription.MedicationReminder.MEDICATION_NAME + " COLLATE NOCASE ASC"); // sort order
            default:
                return null;
        }
    }

    // called by LoaderManager when loading completes
    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        reminderListVoiceAdapter.swapCursor(data);
    }

    // called by LoaderManager when the Loader is being reset
    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        reminderListVoiceAdapter.swapCursor(null);
    }


}
