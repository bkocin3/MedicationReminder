package edu.uic.medicationreminder;

import android.app.AlertDialog;
import android.app.Dialog;
import android.support.v4.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.widget.Toast;

public class ConfirmReminderDeleteFragment extends DialogFragment {

    public static ConfirmReminderDeleteFragment newInstance(int title) {
        ConfirmReminderDeleteFragment frag = new ConfirmReminderDeleteFragment();
        Bundle args = new Bundle();
        args.putInt("title", title);
        frag.setArguments(args);
        return frag;
    }


    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder =
                new AlertDialog.Builder(getActivity());

        builder.setTitle(R.string.confirm_title);
        builder.setMessage(R.string.confirm_message);

        // provide an OK button that simply dismisses the dialog
        builder.setPositiveButton(R.string.button_delete,
                new DialogInterface.OnClickListener() {
                    @Override
                   public void onClick(DialogInterface dialog, int button) {
                        ((ReminderDetailFragment) getActivity().getSupportFragmentManager()
                                .findFragmentById(R.id.fragmentContainer)).onConfirmDialogPositiveClick();

                   }
               }
       );

        builder.setNegativeButton(R.string.button_cancel, null);
        return builder.create(); // return the AlertDialog

        /*
        return new AlertDialog.Builder(getActivity())
                // set dialog icon
                .setIcon(android.R.drawable.stat_notify_error)
                // set Dialog Title
                .setTitle("Alert dialog fragment example")
                // Set Dialog Message
                .setMessage("This is a message")

                // positive button
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getActivity(), "Pressed OK", Toast.LENGTH_SHORT).show();
                    }
                })
                // negative button
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        Toast.makeText(getActivity(), "Cancel", Toast.LENGTH_SHORT).show();
                    }
                }).create();
                */
    }
}
