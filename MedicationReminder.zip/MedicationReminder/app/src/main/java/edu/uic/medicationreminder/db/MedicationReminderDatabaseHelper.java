package edu.uic.medicationreminder.db;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import edu.uic.medicationreminder.db.MedicationReminderDatabaseDescription.MedicationReminder;

public class MedicationReminderDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "MedicationReminder.db";
    private static final int DATABASE_VERSION = 1;

    public MedicationReminderDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        final String CREATE_MEDICATION_REMINDER_TABLE =
                "CREATE TABLE " + MedicationReminder.TABLE_NAME + "(" +
                        MedicationReminder._ID + " integer primary key, " +
                        MedicationReminder.MEDICATION_NAME + " TEXT, " +
                        MedicationReminder.START_DATE + " TEXT, " +
                        MedicationReminder.END_DATE + " TEXT, " +
                        MedicationReminder.DOSAGE + " TEXT, " +
                        MedicationReminder.NOTES + " TEXT);";
        db.execSQL(CREATE_MEDICATION_REMINDER_TABLE); // create the contacts table
    }

    // normally defines how to upgrade the database when the schema changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
    }
}

