package edu.uic.medicationreminder;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.support.v4.app.DialogFragment;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;

import edu.uic.medicationreminder.db.MedicationReminderDatabaseDescription.MedicationReminder;

public class ReminderDetailFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {

    // callback methods implemented by MainActivity
    public interface ReminderDetailFragmentListener {

        void onReminderDeleted();

        void onEditReminder(Uri medicationReminderUri);


    }

    private static final int MEDICATION_REMINDER_LOADER = 0;

    private ReminderDetailFragmentListener listener; // MainActivity
    private Uri medicationReminderUri; // Uri of selected contact

    private TextView nameTextView;
    private TextView startDateTextView;
    private TextView endDateTextView;
    private TextView dosageTextView;
    private TextView notesTextView;

    private Button editButton;
    private Button deleteButton;


    // set DetailFragmentListener when fragment attached
    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        listener = (ReminderDetailFragmentListener) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        setHasOptionsMenu(true);

        Bundle arguments = getArguments();

        if (arguments != null)
            medicationReminderUri = arguments.getParcelable(MainActivity.MEDICATION_REMINDER_URI);

        View view = inflater.inflate(R.layout.fragment_reminder_detail, container, false);

        nameTextView = (TextView) view.findViewById(R.id.nameTextView);
        startDateTextView = (TextView) view.findViewById(R.id.startDateTextView);
        endDateTextView = (TextView) view.findViewById(R.id.endDateTextView);
        dosageTextView = (TextView) view.findViewById(R.id.dosageTextView);
        notesTextView = (TextView) view.findViewById(R.id.notesTextView);

        editButton = (Button) view.findViewById(R.id.edit_button);
        editButton.setOnClickListener(editButtonListener);

        deleteButton = (Button) view.findViewById(R.id.delete_button);
        deleteButton.setOnClickListener(deleteButtonListener);

        getLoaderManager().initLoader(MEDICATION_REMINDER_LOADER, null, this);
        return view;
    }

    private OnClickListener editButtonListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            listener.onEditReminder(medicationReminderUri);
        }
    };


    private OnClickListener deleteButtonListener = new OnClickListener() {
        @Override
        public void onClick(View v) {
            System.out.println(">>> clicked delete button");
            deleteReminder();
        }
    //        //getActivity().getContentResolver().delete(medicationReminderUri, null, null);
    };


    private void deleteReminder() {
        DialogFragment confirmDelete = ConfirmReminderDeleteFragment.newInstance(R.string.confirm_title);
        confirmDelete.show(getFragmentManager(), "confirm_delete_dialog");


    }

    public void onConfirmDialogPositiveClick() {
        getActivity().getContentResolver().delete(medicationReminderUri, null, null);
        listener.onReminderDeleted();
    }




    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {

        CursorLoader cursorLoader;

        switch (id) {
            case MEDICATION_REMINDER_LOADER:
                cursorLoader = new CursorLoader(getActivity(),
                        medicationReminderUri,
                        null, // null projection returns all columns
                        null, // null selection returns all rows
                        null, // no selection arguments
                        null); // sort order
                break;
            default:
                cursorLoader = null;
                break;
        }

        return cursorLoader;
    }

    // called by LoaderManager when loading completes
    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {

        if (data != null && data.moveToFirst()) {
            // get the column index for each data item
            int nameIndex = data.getColumnIndex(MedicationReminder.MEDICATION_NAME);
            int startDateIndex = data.getColumnIndex(MedicationReminder.START_DATE);
            int endDateIndex = data.getColumnIndex(MedicationReminder.END_DATE);
            int dosageIndex = data.getColumnIndex(MedicationReminder.DOSAGE);
            int notesIndex = data.getColumnIndex(MedicationReminder.NOTES);

            nameTextView.setText(data.getString(nameIndex));
            startDateTextView.setText(data.getString(startDateIndex));
            endDateTextView.setText(data.getString(endDateIndex));
            dosageTextView.setText(data.getString(dosageIndex));
            notesTextView.setText(data.getString(notesIndex));
        }
    }

    @Override
    public void onLoaderReset(Loader<Cursor> loader) { }
}