package edu.uic.medicationreminder;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v4.app.LoaderManager;
import android.support.v4.content.CursorLoader;
import android.support.v4.content.Loader;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import edu.uic.medicationreminder.db.MedicationReminderDatabaseDescription.MedicationReminder;

public class ReminderListFragment extends Fragment implements LoaderManager.LoaderCallbacks<Cursor> {

    // callback method implemented by MainActivity
    public interface ReminderListFragmentListener {
        // called when a reminder is selected
        void onReminderSelected(Uri medicationReminderUri);

        // called when add button is pressed
        void onAddReminder();
    }

    private static final int MEDICATION_REMINDER_LOADER = 0;

    private ReminderListFragmentListener listener;

    private ReminderListAdapter reminderListAdapter; // adapter for recyclerView

    // configures this fragment's GUI
    @Override
    public View onCreateView(
            LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        setHasOptionsMenu(true);

        View view = inflater.inflate(
                R.layout.fragment_reminder_list, container, false);
        RecyclerView recyclerView =
                (RecyclerView) view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(
                new LinearLayoutManager(getActivity().getBaseContext()));

        reminderListAdapter = new ReminderListAdapter(
                new ReminderListAdapter.ReminderListClickListener() {
                    @Override
                    public void onClick(Uri medicationReminderUri) {
                        listener.onReminderSelected(medicationReminderUri);
                    }
                }
        );
        recyclerView.setAdapter(reminderListAdapter); // set the adapter

        // attach a custom ItemDecorator to draw dividers between list items
        recyclerView.addItemDecoration(new ItemDivider(getContext()));

        // improves performance if RecyclerView's layout size never changes
        recyclerView.setHasFixedSize(true);

        // get the FloatingActionButton and configure its listener
        FloatingActionButton addButton =
                (FloatingActionButton) view.findViewById(R.id.addButton);
        addButton.setOnClickListener(
                new View.OnClickListener() {
                    // displays the AddEditFragment when FAB is touched
                    @Override
                    public void onClick(View view) {
                        listener.onAddReminder();
                    }
                }
        );

        return view;
    }


    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        listener = (ReminderListFragmentListener) context;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }

    // initialize a Loader when this fragment's activity is created
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getLoaderManager().initLoader(MEDICATION_REMINDER_LOADER, null, this);
    }

    // called from MainActivity when other Fragment's update database
    public void updateReminderList() {
        reminderListAdapter.notifyDataSetChanged();
    }

    // called by LoaderManager to create a Loader
    @Override
    public Loader<Cursor> onCreateLoader(int id, Bundle args) {
        // create an appropriate CursorLoader based on the id argument;
        // only one Loader in this fragment, so the switch is unnecessary
        switch (id) {
            case MEDICATION_REMINDER_LOADER:
                return new CursorLoader(getActivity(),
                        MedicationReminder.CONTENT_URI, // Uri of medication_reminder table
                        null, // null projection returns all columns
                        null, // null selection returns all rows
                        null, // no selection arguments
                        MedicationReminder.MEDICATION_NAME + " COLLATE NOCASE ASC"); // sort order
            default:
                return null;
        }
    }

    // called by LoaderManager when loading completes
    @Override
    public void onLoadFinished(Loader<Cursor> loader, Cursor data) {
        reminderListAdapter.swapCursor(data);
    }

    // called by LoaderManager when the Loader is being reset
    @Override
    public void onLoaderReset(Loader<Cursor> loader) {
        reminderListAdapter.swapCursor(null);
    }
}

